public class EvenNumbers {
    public static void main(String[] args) {
        for(int i=0;i<=50;i++){
            int x = i%2;
            if(x == 0)
                System.out.println(i);
        }
    }
}
