public class AddFunc {

    static int add(int n1, int n2){
        return n1 +n2;
    }

    public static void main(String[] args) {
        int res = add (123,456);
        System.out.println("The sum is: "+res);
    }
}
